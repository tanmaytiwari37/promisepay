import os
from typing import List, Dict, Any, Optional
from pypdf import PdfReader
from app.schemas.ai import VerificationResult, CriterionVerification
from app.services.ai.llm import call_llm_json


def extract_evidence_text(file_path: Optional[str], file_type: Optional[str]) -> str:
    if not file_path or not os.path.exists(file_path):
        return "No attached file provided."

    file_type = (file_type or "").lower()
    if file_type in ["txt", "md"]:
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()[:10000]
        except Exception as e:
            return f"[Error reading text file: {e}]"
    elif file_type == "pdf":
        try:
            reader = PdfReader(file_path)
            extracted = []
            for page in reader.pages[:10]:
                text = page.extract_text()
                if text:
                    extracted.append(text)
            return "\n".join(extracted)[:10000]
        except Exception as e:
            return f"[Error extracting PDF text: {e}]"
    else:
        return f"[Binary submission evidence file: {os.path.basename(file_path)} ({file_type})]"




async def verify_submission_evidence(
    criteria: List[Dict[str, Any]],
    submission_notes: Optional[str],
    file_path: Optional[str],
    file_type: Optional[str]
) -> VerificationResult:

    evidence_text = extract_evidence_text(file_path, file_type)

    if file_type and file_type.lower() not in ["txt", "md", "pdf"]:
        unsupported_file_note = (
            f"File type '{file_type}' is not supported for content extraction. "
            "Only the filename is available; the file contents were not analyzed."
        )
    else:
        unsupported_file_note = None

    criteria_text = "\n".join(
        [f"- ID: {c.get('id')}: {c.get('criterion')}" for c in criteria]
    )

    prompt = f"""
Acceptance Criteria:
{criteria_text}

Freelancer Submission Notes:
{submission_notes or "None provided"}

Extracted Evidence / Content:
{evidence_text}

Verify the submission against each acceptance criterion.

For each criterion, return:
- criterion_id: matching the provided ID
- status: exactly one of "completed", "missing", or "uncertain"
- evidence: direct quote from the extracted content, or explicit filename reference.
- Never invent page numbers, filenames, screenshots, or evidence.
- If no direct evidence supports a criterion, state that clearly.
- reasoning: explain the assessment

Never claim certainty without direct evidence.

Return an overall summary, improvement suggestions, and limitations.
"""

    system_prompt = (
        "You are an objective AI delivery auditor. Evaluate evidence strictly "
        "against criteria without bias. Your role is decision support for the "
        "customer. You must never approve payments or make legal guarantees."
    )

    raw_json = await call_llm_json(prompt, system_prompt)

    if not isinstance(raw_json, dict) or not raw_json:
        verified_items = []

        for i, c in enumerate(criteria):
            cid = c.get("id", f"crit-{i+1}")

            verified_items.append({
                "criterion_id": cid,
                "status": "uncertain",
                "evidence": "No independently verifiable evidence available.",
                "reasoning": (
                    "AI verification service was unavailable or returned "
                    "an invalid response. Manual customer review is required."
                )
            })

        raw_json = {
            "criteria": verified_items,
            "overall_summary": (
                "Automated verification was unavailable. "
                "All criteria require manual customer review."
            ),
            "improvement_suggestions": [
                "Retry verification when the AI service is available.",
                "Request screenshots, source code, or test results as evidence."
            ],
            "limitations": [
                "AI verification service was unavailable or returned invalid data.",
                "No criteria can be independently confirmed.",
                "Customer approval is required before payment capture."
            ]
        }

    # Normalize AI response key
    if "criteria" not in raw_json and "evaluations" in raw_json:
        raw_json["criteria"] = raw_json.pop("evaluations")

    # Normalize text fields into lists
    for field in ["improvement_suggestions", "limitations"]:
        value = raw_json.get(field)

        if value is None:
            raw_json[field] = []
        elif isinstance(value, str):
            raw_json[field] = [value] if value.strip() else []
        elif not isinstance(value, list):
            raw_json[field] = [str(value)]

    if unsupported_file_note:
        raw_json["limitations"] = (
        raw_json.get("limitations", []) + [unsupported_file_note]
        )
        
    return VerificationResult.model_validate(raw_json)


